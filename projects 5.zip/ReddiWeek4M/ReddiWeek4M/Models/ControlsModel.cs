﻿// Created by Satya Praneeth Reddi
// 1111111111111111111111111111111
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace ReddiWeek4M.Models
{
    public class ControlsModel
    {
        //Property for textbox
        [Required(ErrorMessage = "name is a required field.")]
        [Display(Name = "Please Enter Name")]
        public string? Name { get; set; }

        //property for textbox with type as property
        [Required(ErrorMessage = "Customized Personal code is required, and it is your last name!")]
        [Display(Name = "Please enter your personal code.")]
        [DataType(DataType.Password)]
        public string? PersonalCode { get; set; }

        //property for price -- number textbox.
        [Required(ErrorMessage = "Price is required.")]
        [Range(40000, 200000, ErrorMessage = "Your offer price must be between $40000 and $200000")]
        [DataType(DataType.Currency)]
        public int Price { get; set; }

        // underlying property for select control in view. --see the underlying list variable as well
        [Required(ErrorMessage = "Please make a selection for your luxury car.")]
        [Display(Name = "Please select  Luxury Car: ")]
        public string? MyCar { get; set; }

        //Radio button -- one property value being set for/by a group of radio controls in the view.
        [Required(ErrorMessage = "Please select Trim Level")]
        [Display(Name = "Trim Level: ")]
        
        public string? TrimLevel { get; set; }

        // property for checkbox as well as the hidden input which is automatically generated
        public bool TowingPackage { get; set; }

        //property for date picker control
        [Required(ErrorMessage = "Offer Valid Until Date is Required.")]
        [DataType(DataType.Date, ErrorMessage = "Enter a valid Date")]
        public DateTime? OfferValidDate { get; set;}

        //field variable(s) for select dropdown list.
        [Required(ErrorMessage = "Please make a selection for your luxury car.")]
        public List<SelectListItem> MyCarsList = new
            List<SelectListItem>
        {
            //new SelectListItem{Value = "None", Text = " "},
            new SelectListItem{Value = "Mercedes", Text = "Mercedes-Benz-Germany"},
            new SelectListItem{Value = "Lamborghini", Text = "Lamborghini-Italy"},
            new SelectListItem{Value = "Ferrari", Text = "Ferrari-Italy"},
            new SelectListItem{Value = "RollsRoyce", Text = "RollsRoyce-UK"},
            new SelectListItem{Value = "Maseratti", Text = "Maseratti-Italy"},
            new SelectListItem{Value = "Buggati", Text = "Buggati-France"}
        };
    } //ControlsModel
} //namespace
