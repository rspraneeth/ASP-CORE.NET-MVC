﻿using Microsoft.AspNetCore.Mvc;
using ReddiWeek4M.Models;
// Created by Satya Praneeth Reddi
// 3333333333333333333333333333333
namespace ReddiWeek4M.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View(new ControlsModel());
        } //Index()

        [HttpPost]
        public IActionResult Result(ControlsModel ControlsModel)
        {
            if (ModelState.IsValid) // Checking if model is valid.
            {
                // adding some custom validation for date.
                if(ControlsModel.OfferValidDate > DateTime.Now && ControlsModel.OfferValidDate < DateTime.Now.AddDays(90))
                {
                    return View("OfferSummary", ControlsModel);
                } // date validation if
                else
                {
                    //Adding a custom validation error message. This is similar to error messages we have used in
                    //data annotations, and will be displayed inside span element with 'asp-valiation-for = property
                    //name' tag helper or the div element using asp-validation-summary tag helper.  
                    ModelState.AddModelError("OfferValidDate", "The Date must be current and within next 90 days.");
                    return View("Index", ControlsModel);
                } //date validation else

            } //model validation
            //set a viewBag property for the method, that can be accessed from the View.
            ViewBag.FormMethod = HttpContext.Request.Method;
            return View("Index", ControlsModel);
        } //HttpGet Index()
    } //controller class
} //namespace
