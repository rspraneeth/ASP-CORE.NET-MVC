﻿using Microsoft.AspNetCore.Mvc;
using ReddiWeek4MWeightTemperature.Models;
using System.Reflection.Metadata.Ecma335;

namespace ReddiWeek4MWeightTemperature.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Temperature()
        {
            return View(new TemperatureModel());
        }

        public IActionResult Weights()
        {
            return View(new WeightsModel());
        }

        [HttpPost]
        public IActionResult WeightsResult(WeightsModel model) {
            if (ModelState.IsValid)
            {
                return View(model);
            }
            return View(model);
        }

        [HttpPost]
        public IActionResult Temperature(TemperatureModel model)
        {
            if (ModelState.IsValid)
            {
                ViewBag.RoundTrip = "RoundTrip";
                return View(model);
            }
            return View(model);
        }
    }
}
