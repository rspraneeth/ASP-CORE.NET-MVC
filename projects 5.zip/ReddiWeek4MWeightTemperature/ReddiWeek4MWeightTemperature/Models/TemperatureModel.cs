﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace ReddiWeek4MWeightTemperature.Models
{
    public class TemperatureModel
    {
        
        [Required(ErrorMessage = "Please enter temperature")]
        [Display(Name = "Please enter temperature as a decimal or integer.")]
        public decimal Temperature { get; set; }

        [Required(ErrorMessage = "Please select Farenheit or Celsius")]
        public String? TemperatureUnit { get; set; }

        public String ConvertTemp()
        {
            decimal ConversionResult = 0;
            string Result = "";
            switch (TemperatureUnit)
            {
                case "F2C":
                    ConversionResult = (Temperature - 32) * 5 / 9;
                    Result = $"{Temperature:N4} degrees F = {ConversionResult:N4} degrees C";
                    break;
                case "C2F":
                    ConversionResult = (Temperature * 9 / 5) + 32;
                    Result = $"{ConversionResult:N4}&deg; C = {Temperature:N4}&deg; F";
                    break;
            }
            return Result;
        }
    }
}
