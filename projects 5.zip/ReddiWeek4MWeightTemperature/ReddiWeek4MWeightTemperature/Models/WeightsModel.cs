﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace ReddiWeek4MWeightTemperature.Models
{
    public class WeightsModel
    {
        [Display(Name = "Please enter weight in pounds.")]
        [Range(30, 300, ErrorMessage = "Your weight in lbs, must be between 30 and 300.")]
        public int Weight {  get; set; }

        [Display(Name = "Please select Planet.")]
        [NotNull]
        public string? Planet { get; set; }

        public List<SelectListItem> PlanetList { get; set; } = new List<SelectListItem>
        {
            new SelectListItem{Value = "Sun", Text = "Sun"},
            new SelectListItem{Value = "Mercury", Text = "Mercury"},
            new SelectListItem{Value = "Venus", Text = "Venus"},
            new SelectListItem{Value = "Earth", Text = "Earth"},
            new SelectListItem{Value = "Moon", Text = "Moon"},
            new SelectListItem{Value = "Mars", Text = "Mars"},
            new SelectListItem{Value = "Jupiter", Text = "Jupiter"},
            new SelectListItem{Value = "Saturn", Text = "Saturn"},
            new SelectListItem{Value = "Uranus", Text = "Uranus"},
            new SelectListItem{Value = "Neptune", Text = "Neptune"},
            new SelectListItem{Value = "Pluto", Text = "Pluto"}
        };

        private Dictionary<String, double> planetWeights = new Dictionary<string, double>();

        public String GetWeight()
        {
            planetWeights.Add("Sun", 27.01);
            planetWeights.Add("Mercury", 0.38);
            planetWeights.Add("Venus", 0.91);
            planetWeights.Add("Earth", 1);
            planetWeights.Add("Moon", 0.166);
            planetWeights.Add("Mars", 0.38);
            planetWeights.Add("Jupiter", 2.34);
            planetWeights.Add("Saturn", 1.06);
            planetWeights.Add("Uranus", 0.92); 
            planetWeights.Add("Neptune", 1.19);
            planetWeights.Add("Pluto", 0.06);
            return $"Your weight{Weight}lbs on Earth will be equivalent to {planetWeights[Planet]*Weight}lbs on {Planet}";
        }

    }
}
