﻿using Microsoft.AspNetCore.Mvc;
using ReddiWeek3SoftwareBilling.Models;
// Create by Satya Praneeth Reddi
// 222222222222222222222222222222

namespace ReddiWeek3SoftwareBilling.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View(new BillingModel());
        }

        [HttpPost]
        public IActionResult Index(BillingModel model)
        {
            if(ModelState.IsValid) // Validate moel
            {
                return View("Confirmation", model);
            } //if
            return View(model);
        } //Index BillingModel

    }
}
