﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace ReddiWeek3SoftwareBilling.Models
{
    // Created by Satya Praneeth Reddi
    // 1111111111111111111111111111111
    public class BillingModel
    {
        [Required(ErrorMessage = "This is a required field.")]

        public string? CustomerName { get; set; }
        public string? SoftwareCode { get; set; }

        [Range(1, 100, ErrorMessage = "Enter a number between 1 an 100.")]
        public int Users { get; set; }

        [NotNull]
        public List<SelectListItem>? SoftwareList { get; set; } = new List<SelectListItem>
        {
            new SelectListItem{Value = "PM", Text = "Payroll Management", Selected =  true},
            new SelectListItem{Value = "CM", Text = "Customer Management"},
            new SelectListItem{Value = "TM", Text = "Training Management"},
            new SelectListItem{Value = "Other", Text = "Something Else"}
        };

        public string? GetSoftwareName(string value)
        {
            return SoftwareList.FirstOrDefault(x => x.Value == value)?.Text;
        }

        public double GetMonthlyCharge()
        {
            double Cost = 100;
            switch (SoftwareCode)
            {
                case "PM":
                    Cost = Users * 100;
                    break;
                case "CM":
                    Cost = Users * 75;
                    break;
                case "TM":
                    Cost = Users * 80;
                    break;
                case "Other":
                    Cost = Users * 90;
                    break;
            }
            return Cost;
        } // GetMonthlyCharge()
    } // BillingModel
} // namespace
