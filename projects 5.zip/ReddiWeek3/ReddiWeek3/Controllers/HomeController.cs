﻿using Microsoft.AspNetCore.Mvc;
using ReddiWeek3.Models;
// Created by Satya Praneeth Reddi
// 2222222222222222222222222222222

namespace ReddiWeek3.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View(new RealEstateModel()); // returning along with ViewModel
        }

        [HttpPost]
        public IActionResult Result(RealEstateModel model)
        {
            if (ModelState.IsValid)
            {
                model.CalculateHomeValue(); // This method in the model sets the home value.
                return View(model);
            }
            return View("Index", model); // takes you back to the index page that has the form.
                                         // Returning along with the ViewModel will retain the
                                         // values entered by the user (sticky form).
        } //Result()

    } // Controller Class
} // Namepsace.
