﻿// Created by Satya Praneeth Reddi
// 1111111111111111111111111111111
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace ReddiWeek3.Models
{
    public class RealEstateModel
    {
        //Module level variables for calculations.
        private readonly int _bedValueAdd = 25000;
        private readonly int _bathValueAdd = 20000;
        private readonly decimal _areaValue = 159; // value per sft.
        public decimal HomeValue { get; set; } // Property when home value is calculated
        /*
         * Properties underlying form controls, with data annotations for validations
         * Annotations specify the data requirements, and error messages that should be displayed when 
         * the data is invalid. The asp-tag helpers in razor views access these properties and map them
         * to the form controls.
         */
        [Required(ErrorMessage = "Please Enter Your Name")]
        public string? Name { get; set; }

        [Required(ErrorMessage = "Enter Square Footage")]
        [Range((double)500, (double)9999, ErrorMessage = "Square footage should be between 500 and 9999")]
        public Decimal Area { get; set; }

        [Required(ErrorMessage = "Please select number of Bathrooms")]
        [Range((double)2, (double)5, ErrorMessage = "Number of Baths must be between 2 and 5")]
        public Decimal Baths { get; set; }

        //property for select dropdown
        [Required(ErrorMessage = "Please select number of Bedrooms")]
        [Range(1, 7, ErrorMessage = "Bedrooms should be between 1 and 7")]
        public int Bedrooms { get; set; }

        //Underlying List supporting dropdown list items/options
        public List<SelectListItem> BedRoomList { get; set; } = new()
        {
            new SelectListItem { Value = " ", Text = " " },
            new SelectListItem { Value = "1", Text = "One (1)" },
            new SelectListItem { Value = "2", Text = "Two (2)" },
            new SelectListItem { Value = "3", Text = "Three (3)" },
            new SelectListItem { Value = "4", Text = "Four (4)" },
            new SelectListItem { Value = "5", Text = "Five (5)" },
            new SelectListItem { Value = "6", Text = "Six (6)" },
            new SelectListItem { Value = "7", Text = "Seven (7)" }
        }; //BedroomList Property
        public void CalculateHomeValue()
        {
            //This method calculates the homevalue and sets the HomeValue property.
            HomeValue = (Area * _areaValue) + (Bedrooms * _bedValueAdd) + (Baths * _bathValueAdd);
        } // calculate home value()
    } //RealEstateModel Class
} // Namespace.
