﻿using Microsoft.AspNetCore.Mvc;
using MusicStudio.Models;

namespace MusicStudio.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View("Signup", new Signup());
        }

        [HttpPost]
        public IActionResult Index(Signup model)
        {
            if(ModelState.IsValid)
            {
                model.Calculate();
                return View("Confirmation", model);
            }
            return View("Signup");
        }
    }
}
