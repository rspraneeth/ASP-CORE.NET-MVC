﻿using System.ComponentModel.DataAnnotations;

namespace MusicStudio.Models
{
    public class Signup
    {
        [Required(ErrorMessage = "Name is required.")]
        public string? Name { get; set; }

        [Required]
        [Range(1, 2, ErrorMessage = "Number of hours field is required and Max number of hours for a lesson is 2hrs.")]
        public int NoHours { get; set; }

        [Required(ErrorMessage = "Number of lessons per year field is required.")]
        public int NoLessons { get; set; }

        public int Total { get; set; }

        public int SubTotal { get; set; }

        public int Discount { get; set; }

        public void Calculate()
        {
            Discount = 0;
            if (NoLessons > 25) Discount = 30;
            SubTotal = 20 * NoHours * NoLessons;
            Total = SubTotal - Discount;
        }
    }
}
