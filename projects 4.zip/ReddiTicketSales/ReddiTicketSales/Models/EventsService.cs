﻿namespace ReddiTicketSales.Models
{
    public class EventsService
    {
        /*
        Created by Satya Praneeth Reddi
        3333333333333333333333333333333
        This is a class that creates a list of events with each event of type Event class.
        Creates a list of categories with each category of type Category class.
        It has 3 methods:
        GetEvents(), returns events based on incoming parameter category.
        GetCategories(), returns a list of categories or events.
        GetAllEvents(), returns all categories.
         */

        private List<Event> _allEvents = new()
        {
            new Event() { Id = 100, Title = "Avengers: End Game", CategoryID = 1, TicketPrice = 50, Description = "A Theater show, based on how avengers save the Universe from mighty Thanos", ImageId = "100.jpg"},
            new Event() { Id = 200, Title = "The Eillish", CategoryID = 2, TicketPrice = 40, Description = "A Live concert by singer and songwriter Billie Eillish", ImageId = "200.jpg"},
            new Event() { Id = 300, Title = "The Mahabharatha", CategoryID = 1, TicketPrice = 50, Description = "The legend, most famous Indian story", ImageId = "300.jpg"},
            new Event() { Id = 400, Title = "Ed Sheeran", CategoryID = 2, TicketPrice = 90, Description = "A Live concert by singer and songwriter Ed Sheeran", ImageId = "400.jpg"},
            new Event() { Id = 500, Title = "Desi Tales", CategoryID = 1, TicketPrice = 90, Description = "A standup comedy show based on most popular Indian activities", ImageId = "500.jpg"}
        };

        private List<Category> _allCategories = new()
        {
            new Category(){Id = 1, CategoryName = "Theater show"},
            new Category(){Id = 2, CategoryName = "Concert"}
        };

        public Event GetEvent(int id)
        {
            // incoming parameter id comes from the <a> link in the details view,
            // where Id is either all or a specific category name.

            Event? selectedEvent = null;

            foreach(Event anEvent in _allEvents)
            {
                if(anEvent.Id == id)
                {
                    selectedEvent = anEvent;
                } //if        
            } // foreach
            return selectedEvent;
        } // GetEvent()

        public List<Event> GetAllEvents() { return _allEvents; }

        public List<Category> GetCategories() { return _allCategories; }
    } // Events service
} // namespace ReddiTicketSales.Models
