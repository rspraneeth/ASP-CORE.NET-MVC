﻿namespace ReddiTicketSales.Models
{
    /*
    Created by Satya Praneeth Reddi
    2222222222222222222222222222222
    This class creates a type for Events.
    Each event has an event name(Title property), description for the event, 
    the category of the event and has an image to display.
     */
    public class Event
    {
        public int Id { get; set; }
        public string? Title { get; set; }
        public int CategoryID { get; set; }
        public double TicketPrice { get; set; }
        public string? Description { get; set; }
        public string? ImageId { get; set; }
    } // event class
} // namespace ReddiTicketSales.Models
