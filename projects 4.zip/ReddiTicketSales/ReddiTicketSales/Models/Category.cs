﻿namespace ReddiTicketSales.Models
{
    public class Category
    {
        /*
        Created by Satya Praneeth Reddi
        1111111111111111111111111111111
        This class creates a type of categories
        This is the class for categories of shows (theater shows and concerts)
        Each category has two properties: CategoryID and CategoryName.
         */

        public int Id { get; set; }
        public string? CategoryName { get; set; }
    } // Category
} //namespace ReddiTicketSales.Models
