﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace ReddiTicketSales.Models
{
    public class BuyTickets
    {
        /*
        Created by Satya Praneeth Reddi
        5555555555555555555555555555555
        This is the supporting model for Buy View which is a form that accesses this class.
        This class has an overloaded constructor with two signatures: a default constructor
        and one with parameters for event name and for sale and ticket price. Default 
        parameterless constructor is needed for binding model.
        The parameterized constructor is called from the Cart controllers Buy action method, 
        to be sent as view model. Supports Buy form.
        There are two methods: CalculateDiscount() and ProcessSale()
        One collection for dropdown options.
         */

        //constant
        private const Double SR_DISCOUNT_RATE = 0.2D;

        //properties and variables:
        public string? EventName { get; set; }
        public string? CustomerName { get; set; }

        [Required(ErrorMessage = "Email is a required field.")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address.")]
        [Display(Name = "Email Address: ")]
        public string? Email { get; set;}
        public double TicketPrice { get; set; }
        public string? SaleDate { get; set; }

        [Required(ErrorMessage = "Please enter number of tickets.")]
        [Range(1, 10, ErrorMessage = "Number of tickets should be between 1 and 10.")]
        public int NumberOfTickets { get; set; }

        [Display(Name = "Senior Discount: ")]
        public bool SeniorDiscount { get; set; }

        [Required(ErrorMessage = "Delivery option is required.")]
        [Display(Name = "Select mode of delivery: ")]
        public string? DeliveryMode { get; set; } //underlying property for dropdown

        //other properties:
        public double SubTotal { get; set; }
        public double SaleDiscount { get; set; }
        public double DeliveryCharge { get; set; }
        public double AmountDue { get; set; }

        //collection for select dropdown
        public List<SelectListItem> DeliveryOptions = new()
        {
            new SelectListItem {Text = "",  Value = "None"},
            new SelectListItem {Text = "Mail",  Value = "Mail"},
            new SelectListItem {Text = "Print at home",  Value = "Print"},
            new SelectListItem {Text = "Digital Ticket",  Value = "Digital"},
            new SelectListItem {Text = "Will Call",  Value = "Call"}
        };

        public BuyTickets()
        {
            //parameterless constructor for use with binding model
        } // constructor.

        public BuyTickets(string? eventName, double ticketPrice)
        {
            this.EventName = eventName;
            this.TicketPrice = ticketPrice;
        } //Constructor for use with ValueModel.
        
        public void CalculateDiscount()
        {
            this.SaleDiscount = SubTotal * SR_DISCOUNT_RATE;
        } //CalculateDiscount()

        public void CalculateAmountDue()
        {
            //Calculates the amount due and sets the saleDate.
            this.SaleDate = DateTime.Today.ToShortDateString();
            this.SubTotal = TicketPrice * NumberOfTickets;
            //check if there is senior discount:
            if(SeniorDiscount) CalculateDiscount();
            if (DeliveryMode == "Mail") this.DeliveryCharge = 3.95;
            else this.DeliveryCharge = 0;
            this.AmountDue = SubTotal - SaleDiscount + DeliveryCharge;
        }
    } //BuyTickets class
} // namespace ReddiTicketSales.Models
