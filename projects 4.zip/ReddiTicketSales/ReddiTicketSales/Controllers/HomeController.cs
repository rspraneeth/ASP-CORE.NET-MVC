﻿using Microsoft.AspNetCore.Mvc;
using ReddiTicketSales.Models;
using System.Diagnostics;

namespace ReddiTicketSales.Controllers
{
    public class HomeController : Controller
    {
        /*
        Created by Satya Praneeth Reddi
        6666666666666666666666666666666
         */
        
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

    }
}