﻿using Microsoft.AspNetCore.Mvc;
using ReddiTicketSales.Models;

namespace ReddiTicketSales.Controllers
{
    public class EventsController : Controller
    {
        /*
        Created by Satya Praneeth Reddi
        7777777777777777777777777777777
         */
        [ResponseCache(NoStore = true, Duration = 0)]
        public IActionResult EventList(string id = "All")
        {
            //uses EventsService to get the events, either all by default if there is no
            //incoming value, or based on the ID of the event.
            //Instatntiate the event service class:

            EventsService eventsService = new EventsService();

            //list of categories:
            List<Category> categories = new List<Category>();

            //List of Events:
            List<Event> events = new List<Event>();

            categories = eventsService.GetCategories();

            //get the events based on Category ID:
            if(id == "All") {events = eventsService.GetAllEvents(); }
            else
            {
                //Based on ID find the category being asked for, if ID is specified then use the category to
                //return all events of that type.

                //variable to hold category id:
                int selectedCategoryId = 0;
                foreach (Category cat in categories)
                {
                    if (cat.CategoryName == id)
                    {
                        selectedCategoryId = cat.Id;
                    } //if
                } //foreach

                foreach(Event anEvent in eventsService.GetAllEvents())
                {
                    if(anEvent.CategoryID == selectedCategoryId)
                    {
                        events.Add(anEvent);
                    } //if                 
                } //foreach
            } //else

            //return ListViewModel as a ViewModel with a collection of events
            ListViewModel listViewModel = new ListViewModel(events, categories, id);

            return View(listViewModel);
        } //EventList()

        [ResponseCache(NoStore =true, Duration = 0)]
        public IActionResult Details(int id)
        {
            EventsService eventsService = new EventsService();
            Event oneEvent = eventsService.GetEvent(id);
            return View(oneEvent);
        } //Details()
    } //Controller
} //namespace
