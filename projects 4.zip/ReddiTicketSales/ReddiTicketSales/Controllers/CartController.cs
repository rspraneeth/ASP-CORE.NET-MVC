﻿using Microsoft.AspNetCore.Mvc;
using ReddiTicketSales.Models;

namespace ReddiTicketSales.Controllers
{
    public class CartController : Controller
    {
        //Created by Satya Praneeth Reddi
        //8888888888888888888888888888888
        public IActionResult Buy(int id)
        {
            //gets the Id of the event that user wants to buy ticket for an then using the
            // EventsService, gets an object representing the event.

            EventsService eventsService = new EventsService();
            Event selectedEvent = eventsService.GetEvent(id);

            //Start buying ticket by creating buyTicket object an setting name of
            //the event and ticket price. (Constructor of Buy class).
            BuyTickets buyTickets = new BuyTickets(selectedEvent.Title, selectedEvent.TicketPrice);
            return View(buyTickets);
        }

        public IActionResult Confirmation(BuyTickets model)
        {
            if(ModelState.IsValid)
            {
                //call the buyTickets object's method to calculate sale price
                model.CalculateAmountDue();
                //pass buytickets object as viewmodel to display ticket information
                return View(model);
            }
            return View("Buy", model); //take the user back to buy tickets page.
        }
    }
}
