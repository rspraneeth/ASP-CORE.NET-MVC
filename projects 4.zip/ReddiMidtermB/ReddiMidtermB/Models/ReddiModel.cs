﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

// Name: Satya Praneeth Reddi
// Id: 700747451

namespace ReddiMidtermB.Models
{
    public class ReddiModel
    {
        //Number of travellers property, number input field.
        [Required(ErrorMessage = "Number of Travellers field is required.")]
        [Range(1, 10, ErrorMessage = "Number of Travelers must be between 1 and 10.")]
        public int NoOfTravellers { get; set; }

        //Destination property maps with a value selected in dropdown(DestinationsList).
        [Required(ErrorMessage = "Destination is required.")]
        public string? Destination { get; set; }

        //Frequent Flyer checkbox
        public bool FrequentFlyer { get; set; }

        [Required(ErrorMessage = "Please select a destination.")]

        //List of all destinations displayed in dropdown.
        public List<SelectListItem> DestinationsList = new()
        {
            new SelectListItem{Value = "PHL", Text = "Philadelphia, PA"},
            new SelectListItem{Value = "SJC", Text = "San Jose, CA"},
            new SelectListItem{Value = "SFO", Text = "San Francisco, CA"},
            new SelectListItem{Value = "OAK", Text = "Oakland, CA"},
            new SelectListItem{Value = "LGA", Text = "Newyork, NY"},
        };

        // property to assign text for the value selected in DestinationsList
        public string? NameOfCity { get; set; }
        
        //Method to calculate total fare.
        public double CalculateFare()
        {
            foreach (var item in DestinationsList) // iterating through the List, to assign Destination code with text.
            {
                if (item.Value == Destination)
                {
                    NameOfCity = item.Text; break;
                }     
            }

            double totalFare = 0.00;
            if (Destination == "PHL") totalFare = NoOfTravellers * 217;
            else if (Destination == "SJC") totalFare = NoOfTravellers * 215;
            else if (Destination == "SFO") totalFare = NoOfTravellers * 224;
            else if (Destination == "OAK") totalFare = NoOfTravellers * 199;
            else if (Destination == "LGA") totalFare = NoOfTravellers * 129;

            if (FrequentFlyer) totalFare *= 0.9; // checking if there is a discount.

            return totalFare; //returning final total fare 
        } // CalculateFare()
    } //class
} //namespace
