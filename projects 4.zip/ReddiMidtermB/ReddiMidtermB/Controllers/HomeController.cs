﻿using Microsoft.AspNetCore.Mvc;
using ReddiMidtermB.Models;

// Name: Satya Praneeth Reddi
// Id: 700747451

namespace ReddiMidtermB.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View(new ReddiModel()); 
        }

        [HttpPost]
        public IActionResult Search(ReddiModel model) 
        {
            if(ModelState.IsValid) //model state validation
            {
                return View("Index", model); // binding model
            }
            return View("Index", model);
        } //Search()

    } //class
} //namespace
