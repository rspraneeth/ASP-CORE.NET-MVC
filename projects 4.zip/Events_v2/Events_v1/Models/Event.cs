﻿using System.ComponentModel.DataAnnotations;

namespace Events_v2.Models
{
    public class Event
    {
        public int EventId { get; set; }

        [Required]
        public string? Title { get; set; }

        [Required]
        public double TicketPrice { get; set; }

        [Required]
        public string? Description { get; set; }
    }
}
