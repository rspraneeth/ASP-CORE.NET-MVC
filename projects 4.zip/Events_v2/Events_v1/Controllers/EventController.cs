﻿using Events_v2.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.CodeAnalysis;

namespace Events_v2.Controllers
{
    public class EventController : Controller
    {
        private EventContext Context { get; set; }
        public EventController(EventContext ctx)
        {
            Context = ctx;
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Event newEvent)
        {
            if (ModelState.IsValid)
            {
                Context.Events.Add(newEvent);
                Context.SaveChanges();
                return RedirectToAction("List");
            }
            else
            {
                return View(newEvent);
            }
        }

        public IActionResult List()
        {
            List<Event> events = Context.Events.ToList();
            return View(events);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            Event eventToEdit = Context.Events.Find(id);
            return View(eventToEdit);
        }

        [HttpPost]
        public IActionResult Edit(Event eventToUpdate)
        {
            if (ModelState.IsValid)
            {
                Context.Events.Update(eventToUpdate);
                Context.SaveChanges();
                return RedirectToAction("List");
            }
            else
            {
                return View(eventToUpdate);
            }
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            Event eventToDelete = Context.Events.Find(id);
            return View(eventToDelete);
        }

        [HttpPost]
        public IActionResult Delete(Event eventToDelete)
        {
            Context.Events.Remove(eventToDelete);
            Context.SaveChanges();
            return RedirectToAction("List");
        }

    }
}
